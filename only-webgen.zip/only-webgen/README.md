# opengen
An open source account generator.
## Installation
`git clone https://github.com/secremecy/opengen.git` or download directly through the GitHub repository.
## Requirements
A web server and PHP.
## Features
* AJAX
* Easy to use
* Noob friendly
## Preview
https://i.imgur.com/d39eauy.png
## Todo
Add captcha and API rate limiting to prevent backend spam.
## Donate
Like what you're seeing? feel free to buy us a cup of coffee via Bitcoin `1G4zsUzBYJM4PCXV1qNrFW5DTrCyZLqoQF` 😎
